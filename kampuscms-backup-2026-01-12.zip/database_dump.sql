--
-- PostgreSQL database dump
--

\restrict 43vj9rZV6VilTqdzhNcmo4Uh1v90wgINl3tbrWk9mJjesbuGOYKt9TSbEUsPB2z

-- Dumped from database version 15.15
-- Dumped by pg_dump version 18.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public."Staff" DROP CONSTRAINT IF EXISTS "Staff_userId_fkey";
ALTER TABLE IF EXISTS ONLY public."ProgramStudi" DROP CONSTRAINT IF EXISTS "ProgramStudi_headOfProdiId_fkey";
ALTER TABLE IF EXISTS ONLY public."Post" DROP CONSTRAINT IF EXISTS "Post_authorId_fkey";
ALTER TABLE IF EXISTS ONLY public."GalleryImage" DROP CONSTRAINT IF EXISTS "GalleryImage_albumId_fkey";
DROP INDEX IF EXISTS public."User_email_key";
DROP INDEX IF EXISTS public."TracerResponse_nim_key";
DROP INDEX IF EXISTS public."Staff_userId_key";
DROP INDEX IF EXISTS public."Staff_slug_key";
DROP INDEX IF EXISTS public."ProgramStudi_code_key";
DROP INDEX IF EXISTS public."Post_slug_key";
DROP INDEX IF EXISTS public."Page_slug_key";
DROP INDEX IF EXISTS public."Event_slug_key";
ALTER TABLE IF EXISTS ONLY public."User" DROP CONSTRAINT IF EXISTS "User_pkey";
ALTER TABLE IF EXISTS ONLY public."TracerResponse" DROP CONSTRAINT IF EXISTS "TracerResponse_pkey";
ALTER TABLE IF EXISTS ONLY public."Testimonial" DROP CONSTRAINT IF EXISTS "Testimonial_pkey";
ALTER TABLE IF EXISTS ONLY public."Staff" DROP CONSTRAINT IF EXISTS "Staff_pkey";
ALTER TABLE IF EXISTS ONLY public."SiteSettings" DROP CONSTRAINT IF EXISTS "SiteSettings_pkey";
ALTER TABLE IF EXISTS ONLY public."Setting" DROP CONSTRAINT IF EXISTS "Setting_pkey";
ALTER TABLE IF EXISTS ONLY public."ProgramStudi" DROP CONSTRAINT IF EXISTS "ProgramStudi_pkey";
ALTER TABLE IF EXISTS ONLY public."Post" DROP CONSTRAINT IF EXISTS "Post_pkey";
ALTER TABLE IF EXISTS ONLY public."Page" DROP CONSTRAINT IF EXISTS "Page_pkey";
ALTER TABLE IF EXISTS ONLY public."GalleryImage" DROP CONSTRAINT IF EXISTS "GalleryImage_pkey";
ALTER TABLE IF EXISTS ONLY public."GalleryAlbum" DROP CONSTRAINT IF EXISTS "GalleryAlbum_pkey";
ALTER TABLE IF EXISTS ONLY public."Event" DROP CONSTRAINT IF EXISTS "Event_pkey";
ALTER TABLE IF EXISTS ONLY public."Download" DROP CONSTRAINT IF EXISTS "Download_pkey";
ALTER TABLE IF EXISTS ONLY public."Alert" DROP CONSTRAINT IF EXISTS "Alert_pkey";
DROP TABLE IF EXISTS public."User";
DROP TABLE IF EXISTS public."TracerResponse";
DROP TABLE IF EXISTS public."Testimonial";
DROP TABLE IF EXISTS public."Staff";
DROP TABLE IF EXISTS public."SiteSettings";
DROP TABLE IF EXISTS public."Setting";
DROP TABLE IF EXISTS public."ProgramStudi";
DROP TABLE IF EXISTS public."Post";
DROP TABLE IF EXISTS public."Page";
DROP TABLE IF EXISTS public."GalleryImage";
DROP TABLE IF EXISTS public."GalleryAlbum";
DROP TABLE IF EXISTS public."Event";
DROP TABLE IF EXISTS public."Download";
DROP TABLE IF EXISTS public."Alert";
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Alert; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Alert" (
    id text NOT NULL,
    content text NOT NULL,
    link text,
    "isActive" boolean DEFAULT true NOT NULL,
    "startDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "endDate" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Download; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Download" (
    id text NOT NULL,
    title text NOT NULL,
    "fileUrl" text NOT NULL,
    category text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Event; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Event" (
    id text NOT NULL,
    title text NOT NULL,
    slug text NOT NULL,
    description text,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone,
    location text,
    image text,
    category text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: GalleryAlbum; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."GalleryAlbum" (
    id text NOT NULL,
    title text NOT NULL,
    description text,
    "coverImage" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: GalleryImage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."GalleryImage" (
    id text NOT NULL,
    url text NOT NULL,
    caption text,
    size integer,
    width integer,
    height integer,
    "albumId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Page; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Page" (
    id text NOT NULL,
    title text NOT NULL,
    slug text NOT NULL,
    content jsonb,
    published boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Post; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Post" (
    id text NOT NULL,
    title text NOT NULL,
    slug text NOT NULL,
    content text,
    image text,
    published boolean DEFAULT false NOT NULL,
    "authorId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: ProgramStudi; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProgramStudi" (
    id text NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    degree text NOT NULL,
    vision text,
    mission text,
    accreditation text,
    "headOfProdiId" text,
    curriculum jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Setting; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Setting" (
    key text NOT NULL,
    value jsonb NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: SiteSettings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SiteSettings" (
    id text NOT NULL,
    name text DEFAULT 'KampusCMS'::text NOT NULL,
    description text,
    logo text,
    colors jsonb,
    fonts jsonb,
    "headerLinks" jsonb,
    "footerText" text,
    "headCode" text,
    "bodyCode" text,
    "pddiktiUrl" text DEFAULT 'https://api-frontend.kemdikbud.go.id'::text,
    "aiConfig" jsonb,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "footerConfig" jsonb
);


--
-- Name: Staff; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Staff" (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    nidn text,
    role text,
    bio text,
    image text,
    links jsonb,
    "pddiktiData" jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "userId" text
);


--
-- Name: Testimonial; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Testimonial" (
    id text NOT NULL,
    name text NOT NULL,
    role text NOT NULL,
    content text NOT NULL,
    avatar text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: TracerResponse; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TracerResponse" (
    id text NOT NULL,
    nim text NOT NULL,
    nama text NOT NULL,
    "kodeProdi" text NOT NULL,
    "tahunLulus" integer NOT NULL,
    "nomorHP" text,
    email text,
    status text NOT NULL,
    "bidangKerja" text,
    "namaPerusahaan" text,
    "jenisInstansi" text,
    jabatan text,
    "waktuTunggu" integer,
    gaji text,
    "kesesuaianBidang" text,
    feedback text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: User; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    name text,
    role text DEFAULT 'editor'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Data for Name: Alert; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Alert" (id, content, link, "isActive", "startDate", "endDate", "createdAt", "updatedAt") FROM stdin;
cmk2l1o6100054501pvph8a2x	Pendaftaran PENERIMAAN MAHASISWA BARU GELOMBANG PERTAMA DI BUKA		t	2026-01-06 12:45:39.094	\N	2026-01-06 12:45:39.096	2026-01-06 12:45:39.096
cmk2l2xg600064501mcirhs94	Gabung yuk		t	2026-01-06 12:46:37.779	\N	2026-01-06 12:46:37.781	2026-01-06 12:46:37.781
cmk4xhz4r000545017j142hot	Besok Jumat		t	2026-01-08 04:09:47.544	\N	2026-01-08 04:09:47.546	2026-01-08 04:09:47.546
\.


--
-- Data for Name: Download; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Download" (id, title, "fileUrl", category, "createdAt", "updatedAt") FROM stdin;
cmk2u8c9k000245013xnaavj8	sadasda	/uploads/1767718963545-560670222-Kwitansi-Registrasi-KRS-20251.pdf	Akademik	2026-01-06 17:02:46.808	2026-01-06 17:02:46.808
cmk2unbl400024501t1afkiqw	dsada	/uploads/1767719661882-952258747-droidstar_communication_log.jpg	Akademik	2026-01-06 17:14:25.767	2026-01-06 17:14:25.767
\.


--
-- Data for Name: Event; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Event" (id, title, slug, description, "startDate", "endDate", location, image, category, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: GalleryAlbum; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."GalleryAlbum" (id, title, description, "coverImage", "createdAt", "updatedAt") FROM stdin;
cmk2bg6i800004501juugzuva	test	asdadad	/uploads/1767687415460-970161107-droidstar_home_screen.jpg	2026-01-06 08:16:59.887	2026-01-06 16:20:01.382
cmk9z8n4e00074501x8yee5h9	KKNT 2026	pelepasan mahasiswa KKNT dan magang 2026		2026-01-11 16:57:22.13	2026-01-11 16:57:49.088
cmk9z9rjs00084501gzkm0bxq	WISUDA 2025	wisudawan 2025		2026-01-11 16:58:14.583	2026-01-11 16:58:14.583
cmk9zg6mh00094501zd17mlvu	KEGIATAN MAHASISWA			2026-01-11 17:03:14.056	2026-01-11 17:03:14.056
\.


--
-- Data for Name: GalleryImage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."GalleryImage" (id, url, caption, size, width, height, "albumId", "createdAt") FROM stdin;
\.


--
-- Data for Name: Page; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Page" (id, title, slug, content, published, "createdAt", "updatedAt") FROM stdin;
cmk2ai1kc00094501ojlsutpo	New Page	/pasca	[{"id": "e531f671-d50d-44fc-b500-990cc2deb15c", "type": "hero", "content": {"title": "Program Pascasarjana", "ctaLink": "#", "ctaText": "Pasca_MM", "subtitle": "Universitas Wira Bhakti", "backgroundColor": "#072e83", "backgroundImage": "/placeholder.jpg", "secondaryCtaText": "Pasca_MM"}}, {"id": "6221d83b-451a-49e4-b6ee-fc759b356967", "type": "prodi-grid", "content": {"count": 1, "title": "Program Sutudi", "description": "Magister(S2)"}}, {"id": "7b98b5bc-7ea4-403c-8abc-d4890c4a3733", "type": "gallery", "content": {"count": 3, "title": "Campus Gallery", "subtitle": "Latest photos"}}, {"id": "a00b89d1-cc5a-4ae1-a3ac-f98e5fb07c8a", "type": "tracer-stats", "content": {"title": "Alumni Success", "description": "See how our graduates are performing in the professional world."}}]	t	2026-01-06 07:50:27.181	2026-01-08 04:17:14.458
cmk3m05y500004501qtfvsb7p	New Page	/saintek	[{"id": "5429afa4-d799-4874-9530-14affa7e326b", "type": "hero", "content": {"title": "FAKULTAS SAINS & TEKNOLOGI", "ctaLink": "#", "ctaText": "DAFTAR ", "subtitle": "KEUNGGULAN DALAM PENDIDIKAN", "backgroundImage": "/uploads/1767765466945-297887550-SAINTEK.jpg?v=1767765466950"}}, {"id": "a18e4b03-f668-4892-995a-c78ea175f3fd", "type": "cards", "content": {"items": [{"link": "#", "image": "", "title": "DEKAN", "description": "Description here"}, {"link": "#", "image": "", "title": "KETUA PRODI ILMU PERIKANAN", "description": "Description here"}, {"link": "#", "image": "", "title": "KETUA PRODI ILMU PERIKANAN", "description": "Description here"}, {"link": "#", "image": "", "title": "KETUA PRODI TEKNIK INDUSTRI", "description": "Description"}], "title": "", "columns": 4}}, {"id": "cbc115ca-da49-4cfd-8811-c8346e50bada", "type": "cards", "content": {"items": [{"link": "", "image": "", "title": "ILMU PERIKANAN", "description": "TERAKREDITASI"}, {"link": "", "image": "", "title": "ILMU LINGKUNGAN", "description": "TERAKREDITASI"}, {"link": "", "image": "", "title": "TEKNIK INDUSTRI", "description": "AKREDITASI BAIK"}], "title": "PROGRAM STUDI", "columns": 3}}]	t	2026-01-07 06:00:14.621	2026-01-11 17:33:37.061
cmk2wxfqi00004501cfq9qmom	test berita	/socials	[{"id": "1bf00f7e-99a5-469f-9660-7717ca2f8468", "type": "rss", "content": {"count": 3, "title": "Latest Updates", "layout": "grid", "keyword": "Universitas Wira Bhakti"}}, {"id": "f87eb2ec-9d97-4132-a2dd-d5cc90c7a71d", "type": "social", "content": {"url": "https://www.youtube.com/watch?v=ALFQFO40h3I", "mode": "url", "title": "Follow Us", "platform": "youtube"}}, {"id": "2ebf80b8-2a5d-4070-8b60-c23522c1e985", "type": "social", "content": {"url": "https://www.tiktok.com/tag/wirabhaktimakassar?lang=fi-FI", "mode": "url", "title": "Follow Us", "platform": "tiktok"}}]	t	2026-01-06 18:18:16.938	2026-01-07 03:25:32.061
cmk8aumdh000645019ed82j8y	New Page	/RPL	[{"id": "c80517ae-362a-43a6-80ba-486dd2ba2b95", "type": "hero", "content": {"title": "Rekognisi Pembelajaran Lampau", "ctaLink": "#", "ctaText": "Learn More", "subtitle": "RPL", "backgroundImage": "/placeholder.jpg"}}]	t	2026-01-10 12:46:51.076	2026-01-10 12:46:51.076
cmk29qgne0001450147777oje	New Page	/	[{"id": "5429afa4-d799-4874-9530-14affa7e326b", "type": "hero", "content": {"title": "UNIVERSITAS WIRA BHAKTI", "ctaLink": "#", "ctaText": "DAFTAR ", "subtitle": "KEUNGGULAN DALAM PENDIDIKAN", "backgroundColor": "#001747", "backgroundImage": "/uploads/1767765751635-38179634-Untitled-1.jpg?v=1767765751640"}}, {"id": "846cc2f9-ae07-4941-8adc-0a469a3cc5e1", "type": "text", "content": {"html": "<ul><li><p style=\\"text-align: justify;\\"><strong>Universitas Wira Bhakti adalah tempat lahirnya generasi berkarakter, berilmu, dan berdaya saing. Dengan semangat pengabdian dan integritas, Universitas Wira Bhakti berkomitmen mencetak lulusan yang siap berkontribusi nyata bagi masyarakat, bangsa, dan negara.</strong></p></li><li><p></p></li><li><p></p></li></ul><p></p>", "styles": {"color": "#02277e", "fontSize": "17px", "fontFamily": "monospace"}}}, {"id": "e54c96a2-cbb6-4cba-b416-b143c42b83bb", "type": "columns", "content": {"count": 2, "columns": [{"html": "<p></p>"}, {"html": "<p></p>"}, {"html": "<p>Column 3 content...</p>"}]}}, {"id": "cbc115ca-da49-4cfd-8811-c8346e50bada", "type": "cards", "content": {"items": [{"link": "https://uwb.ac.id/feb", "image": "/uploads/1767765810100-987425414-PICTU.jpg?v=1767765810104", "title": "FAKULTAS EKONOMI & BISNIS", "description": ""}, {"link": "https://uwb.ac.id/saintek", "image": "/uploads/1767765852461-946814183-SAINTEK.jpg?v=1767765852467", "title": "FAKULTAS SAINS & TEKNOLOGI", "description": ""}, {"link": "https://uwb.ac.id/pasca", "image": "/uploads/1767765905204-244425081-PASCA.jpg?v=1767765905210", "title": "PROGRAM PASCASARJANA", "description": ""}, {"link": "https://uwb.ac.id/RPL", "image": "/uploads/1768049116305-620319269-Untitled-1.jpg?v=1768049116314", "title": "RPL", "description": "Rekognisi Pembelajaran Lampau"}], "title": "PROGRAM PENDIDIKAN UNIVERSITAS WIRA BHAKTI", "columns": 4}}, {"id": "ad4ba954-c165-4c6c-a91a-e0b342c33ac9", "type": "features", "content": {"items": [{"title": "BEM FAKULTAS", "description": "Learn from the best."}, {"title": "UKM GRADASI", "description": "State of the art labs."}, {"title": "UKM LITERASI", "description": "Connect with the world."}, {"title": "HMJM", "description": "HIMPUNAN MAHASISWA JURUSAN MANAJEMEN"}, {"title": "HMJA", "description": "HIMPUNAN MAHASISWA JURUSAN AKUNTANSI"}], "title": "LEMBAGA ORGANISASI INTERNAL", "subtitle": ""}}, {"id": "52b72e0a-aa6e-4e31-8c60-21821d0a6e5d", "type": "gallery", "content": {"count": 3, "title": "Campus Gallery", "subtitle": "Latest photos"}}, {"id": "35626208-d21e-4b6c-bcfe-f9d441a56915", "type": "contact", "content": {"email": "contact@wirabhaktimakassar.ac.id", "phone": "+62 81779544002", "title": "Contact ", "mapUrl": "https://maps.app.goo.gl/FeyVeXbjLdirACp18", "address": "<p>JL.AP Pettarani No.72 Makassar</p>"}}, {"id": "0cc734e9-bd71-4929-8ce7-e1937d1ca688", "type": "social", "content": {"url": "https://www.instagram.com/wirabhaktimakassar/?hl=id", "code": "", "mode": "url", "title": "Follow instagram", "platform": "instagram"}}]	t	2026-01-06 07:29:00.361	2026-01-12 03:04:47.968
cmk3n2v9w00024501dpzlczcj	New Page	/LPPM	[{"id": "ef13d208-57d4-4e06-99c6-56053b76ec44", "type": "hero", "content": {"title": "LEMBAGA PENELITIAN & PENGABDIAN MASYARAKAT", "ctaLink": "#", "ctaText": "Learn More", "subtitle": "LPPM", "backgroundImage": "/placeholder.jpg", "secondaryCtaLink": ""}}, {"id": "2661d816-9bd0-4299-8451-2192a08af5bc", "type": "cards", "content": {"items": [{"link": "#", "image": "", "title": "Card 1", "description": "Description here"}, {"link": "#", "image": "", "title": "Card 2", "description": "Description here"}, {"link": "#", "image": "", "title": "Card 3", "description": "Description here"}], "title": "MAGANG BERSERTIFIKAT", "columns": 3}}, {"id": "b16c3106-8c54-4371-8dac-e40a179d4ab3", "type": "cards", "content": {"items": [{"link": "#", "image": "", "title": "POS 01", "description": "Description here"}, {"link": "#", "image": "", "title": "POS 02", "description": "Description here"}, {"link": "#", "image": "", "title": "POS 03", "description": "Description here"}, {"link": "#", "image": "", "title": "POS 04", "description": "Description"}], "title": "KKNT  2026", "columns": 4}}, {"id": "62887ed4-35f4-4d5e-ac73-47a5ebb12908", "type": "cards", "content": {"items": [{"link": "#", "image": "", "title": "POS 05", "description": "Description here"}, {"link": "#", "image": "", "title": "POS 06", "description": "Description here"}, {"link": "#", "image": "", "title": "POS 07", "description": "Description here"}, {"link": "#", "image": "", "title": "POS 08", "description": "Description"}], "title": "", "columns": 4}}, {"id": "42f96e4e-ac19-43cc-9b9e-ee75c66cfdec", "type": "cards", "content": {"items": [{"link": "#", "image": "", "title": "POS 09", "description": "Description here"}, {"link": "#", "image": "", "title": "POS 10", "description": "Description here"}, {"link": "#", "image": "", "title": "POS 11", "description": "Description here"}, {"link": "#", "image": "", "title": "POS 12", "description": "Description"}], "title": "", "columns": 3}}, {"id": "f3013d2c-5a98-4d3a-80da-72a2d53af655", "type": "cards", "content": {"items": [{"link": "#", "image": "", "title": "Card 1", "description": "Description here"}, {"link": "#", "image": "", "title": "Card 2", "description": "Description here"}, {"link": "#", "image": "", "title": "Card 3", "description": "Description here"}, {"link": "#", "image": "", "title": "New Card", "description": "Description"}], "title": "PENELITIAN  FUNDAMENTAL", "columns": 4}}, {"id": "a40d66fa-7999-4626-bf24-1099a536292d", "type": "separator", "content": {"color": "transparent", "height": 20, "showLine": false}}, {"id": "50f5f7cf-77e4-4655-8842-fe658d750217", "type": "social", "content": {"url": "https://www.youtube.com/watch?v=ALFQFO40h3I", "mode": "url", "title": "KOSA BANGSA  UWIBHA DI TANAH TORAJA", "platform": "youtube"}}, {"id": "50e79561-6c17-4b15-801b-984aa6e61f62", "type": "social", "content": {"url": "https://www.youtube.com/watch?v=kodYK9QS5O0", "mode": "url", "title": "KOSA BANGSA UWIBHA DI PANGKEP", "platform": "youtube"}}]	t	2026-01-07 06:30:20.372	2026-01-07 07:01:22.311
cmk4xb4do00034501gd0jrexb	New Page	press/	[]	t	2026-01-08 04:04:27.756	2026-01-08 04:04:27.756
cmk4xbcr0000445010u6qhxn9	halaman press	press	[{"id": "ffb414fd-4e88-4bfa-ac80-5b52fb8ad546", "type": "hero", "content": {"title": "Welcome to Our Campus", "ctaLink": "#", "ctaText": "Learn More", "subtitle": "Excellence in Education", "backgroundImage": "/placeholder.jpg"}}, {"id": "3616ac45-ab68-4044-867b-19a5a819f52c", "type": "news-grid", "content": {"count": 3, "title": "Latest News"}}]	t	2026-01-08 04:04:38.605	2026-01-08 04:04:57.071
cmk3ma3zv00014501ydttr6im	New Page	/feb	[{"id": "d7005952-6b56-4411-9750-ad0f76a1303b", "type": "hero", "content": {"title": "FAKULTAS EKONOMI &  BISNIS", "styles": {"fontSize": "14px", "fontFamily": "'Open Sans', sans-serif"}, "ctaLink": "", "ctaText": "DAFTAR", "subtitle": "KEUNGGULAN DALAM MOTIVASI", "backgroundImage": "/uploads/1767766076130-556880982-PICTU.jpg?v=1767766076138"}}, {"id": "1258de35-0114-4c5c-95a5-906e17d14d9f", "type": "cards", "content": {"items": [{"link": "#", "image": "", "title": "DEKAN", "description": "Description here"}, {"link": "#", "image": "", "title": "KETUA PRODI MANAJEMEN", "description": "Description here"}, {"link": "#", "image": "", "title": "KETUA PRODI AKUNTANSI", "description": "Description here"}], "title": "", "columns": 3}}, {"id": "3dd2157f-fee8-4ba9-b0ed-2374e72b6ee8", "type": "cards", "content": {"items": [{"link": "#", "image": "", "title": "MANAJEMEN", "description": "AKREDITASI B"}, {"link": "#", "image": "", "title": "AKUNTANSI", "description": "AKREDITASI B"}], "title": "PROGRAM STUDI", "columns": 2}}]	t	2026-01-07 06:07:58.651	2026-01-12 02:58:08.33
\.


--
-- Data for Name: Post; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Post" (id, title, slug, content, image, published, "authorId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ProgramStudi; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ProgramStudi" (id, code, name, degree, vision, mission, accreditation, "headOfProdiId", curriculum, "createdAt", "updatedAt") FROM stdin;
cmk2a6irp00074501ny8rummq	mnjs2	Manajemen (S2)	S2	<p>Selalu terbarukan</p>	<p>Selalu berhasil</p>	Baik	cmk29vu040005450147pn1c88	[{"courses": [{"code": "1231232", "name": "fafafasfaafafasas", "credits": 3}], "semester": 1}]	2026-01-06 07:41:29.605	2026-01-06 08:21:21.685
\.


--
-- Data for Name: Setting; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Setting" (key, value, "updatedAt") FROM stdin;
\.


--
-- Data for Name: SiteSettings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SiteSettings" (id, name, description, logo, colors, fonts, "headerLinks", "footerText", "headCode", "bodyCode", "pddiktiUrl", "aiConfig", "updatedAt", "footerConfig") FROM stdin;
cmk29rkum00024501nd0lxz8x	Halo dari Uwibha	Website utama dari Universitas Wira Bhakti	/uploads/1767712593954-361667606-LOGO_UWB_baru.png	{"primary": "#02277e", "secondary": "#3b82f6"}	{"body": "Inter", "heading": "Inter"}	[]	UWIBHA	<meta name="google-site-verification" content="83A2w3fPS0kHtA9p3M5oJNeAZFPfhr2gkDl-BoHlUL0" />\n<meta name="google-adsense-account" content="ca-pub-9845335170263588">	\N	https://api-frontend.kemdikbud.go.id	{"provider": "gemini", "geminiKey": "", "openaiKey": ""}	2026-01-11 16:53:33.691	{"contact": "contact@wirabhaktimakassar.ac.id\\n081779544002", "description": ""}
\.


--
-- Data for Name: Staff; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Staff" (id, name, slug, nidn, role, bio, image, links, "pddiktiData", "createdAt", "updatedAt", "userId") FROM stdin;
cmk29vu040005450147pn1c88	A Imam Zulfikar Mustaman	imamimam	0913118702	Dosen Sangat Luar Biasa	paling jago lah		[{"url": "", "icon": "gaming", "label": "Main yuk"}, {"url": "", "icon": "instagram", "label": "instagram"}]	\N	2026-01-06 07:33:10.948	2026-01-08 04:14:38.034	\N
\.


--
-- Data for Name: Testimonial; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Testimonial" (id, name, role, content, avatar, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: TracerResponse; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."TracerResponse" (id, nim, nama, "kodeProdi", "tahunLulus", "nomorHP", email, status, "bidangKerja", "namaPerusahaan", "jenisInstansi", jabatan, "waktuTunggu", gaji, "kesesuaianBidang", feedback, "createdAt", "updatedAt") FROM stdin;
cmk2aagtu000845012oge4fot	033010121	Risal	61101	2025	081243932011	risal@wirabhaktimakassar.ac.id	Kerja	NGO	Universitas Wira BHakti		Kepala PDPT	0	< 3 Juta	Tidak	Good Job	2026-01-06 07:44:33.714	2026-01-06 07:44:33.714
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."User" (id, email, password, name, role, "createdAt", "updatedAt") FROM stdin;
cmk29ogfo00004501mk0rnd6h	contact@wirabhaktimakassar.ac.id	$2b$10$.EV2bAT/InOK5UdW7/jNs.oQVDbgGTDcBDjDnz7TFzrg55B0fx45i	adminadmin	admin	2026-01-06 07:27:26.772	2026-01-06 07:27:26.772
\.


--
-- Name: Alert Alert_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Alert"
    ADD CONSTRAINT "Alert_pkey" PRIMARY KEY (id);


--
-- Name: Download Download_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Download"
    ADD CONSTRAINT "Download_pkey" PRIMARY KEY (id);


--
-- Name: Event Event_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Event"
    ADD CONSTRAINT "Event_pkey" PRIMARY KEY (id);


--
-- Name: GalleryAlbum GalleryAlbum_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GalleryAlbum"
    ADD CONSTRAINT "GalleryAlbum_pkey" PRIMARY KEY (id);


--
-- Name: GalleryImage GalleryImage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GalleryImage"
    ADD CONSTRAINT "GalleryImage_pkey" PRIMARY KEY (id);


--
-- Name: Page Page_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Page"
    ADD CONSTRAINT "Page_pkey" PRIMARY KEY (id);


--
-- Name: Post Post_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Post"
    ADD CONSTRAINT "Post_pkey" PRIMARY KEY (id);


--
-- Name: ProgramStudi ProgramStudi_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProgramStudi"
    ADD CONSTRAINT "ProgramStudi_pkey" PRIMARY KEY (id);


--
-- Name: Setting Setting_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Setting"
    ADD CONSTRAINT "Setting_pkey" PRIMARY KEY (key);


--
-- Name: SiteSettings SiteSettings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SiteSettings"
    ADD CONSTRAINT "SiteSettings_pkey" PRIMARY KEY (id);


--
-- Name: Staff Staff_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Staff"
    ADD CONSTRAINT "Staff_pkey" PRIMARY KEY (id);


--
-- Name: Testimonial Testimonial_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Testimonial"
    ADD CONSTRAINT "Testimonial_pkey" PRIMARY KEY (id);


--
-- Name: TracerResponse TracerResponse_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TracerResponse"
    ADD CONSTRAINT "TracerResponse_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: Event_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Event_slug_key" ON public."Event" USING btree (slug);


--
-- Name: Page_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Page_slug_key" ON public."Page" USING btree (slug);


--
-- Name: Post_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Post_slug_key" ON public."Post" USING btree (slug);


--
-- Name: ProgramStudi_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "ProgramStudi_code_key" ON public."ProgramStudi" USING btree (code);


--
-- Name: Staff_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Staff_slug_key" ON public."Staff" USING btree (slug);


--
-- Name: Staff_userId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Staff_userId_key" ON public."Staff" USING btree ("userId");


--
-- Name: TracerResponse_nim_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "TracerResponse_nim_key" ON public."TracerResponse" USING btree (nim);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: GalleryImage GalleryImage_albumId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GalleryImage"
    ADD CONSTRAINT "GalleryImage_albumId_fkey" FOREIGN KEY ("albumId") REFERENCES public."GalleryAlbum"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Post Post_authorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Post"
    ADD CONSTRAINT "Post_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ProgramStudi ProgramStudi_headOfProdiId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProgramStudi"
    ADD CONSTRAINT "ProgramStudi_headOfProdiId_fkey" FOREIGN KEY ("headOfProdiId") REFERENCES public."Staff"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Staff Staff_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Staff"
    ADD CONSTRAINT "Staff_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict 43vj9rZV6VilTqdzhNcmo4Uh1v90wgINl3tbrWk9mJjesbuGOYKt9TSbEUsPB2z

